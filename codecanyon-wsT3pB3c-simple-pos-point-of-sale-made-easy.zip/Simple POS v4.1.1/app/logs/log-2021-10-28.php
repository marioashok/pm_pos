<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-28 11:45:25 --> 404 Page Not Found: Uploads/logo1.png
