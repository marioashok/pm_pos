<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-25 16:37:10 --> 404 Page Not Found: Uploads/logo1.png
