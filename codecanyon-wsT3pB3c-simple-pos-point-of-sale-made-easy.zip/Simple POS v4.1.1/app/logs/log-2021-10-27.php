<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-27 16:34:59 --> 404 Page Not Found: Uploads/logo1.png
