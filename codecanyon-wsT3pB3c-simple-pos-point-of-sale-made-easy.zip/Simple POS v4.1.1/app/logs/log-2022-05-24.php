<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-24 17:37:05 --> 404 Page Not Found: Uploads/logo1.png
