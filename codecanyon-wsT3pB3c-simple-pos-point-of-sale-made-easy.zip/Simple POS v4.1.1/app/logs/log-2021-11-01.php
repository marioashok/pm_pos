<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-01 11:24:34 --> 404 Page Not Found: Uploads/logo1.png
ERROR - 2021-11-01 11:25:19 --> 404 Page Not Found: Faviconico/index
