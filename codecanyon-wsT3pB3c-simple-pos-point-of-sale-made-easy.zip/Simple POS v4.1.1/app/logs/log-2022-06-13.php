<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-13 17:37:12 --> 404 Page Not Found: Uploads/logo1.png
ERROR - 2022-06-13 17:45:58 --> Could not find the language line "closed_at"
