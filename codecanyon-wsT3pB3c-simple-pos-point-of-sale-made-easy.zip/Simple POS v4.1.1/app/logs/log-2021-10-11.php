<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$ws_barcode_type /Users/saleem/Sites/spos/themes/default/views/settings/index.php 185
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$ws_barcode_chars /Users/saleem/Sites/spos/themes/default/views/settings/index.php 195
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$flag_chars /Users/saleem/Sites/spos/themes/default/views/settings/index.php 205
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$item_code_start /Users/saleem/Sites/spos/themes/default/views/settings/index.php 215
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$item_code_chars /Users/saleem/Sites/spos/themes/default/views/settings/index.php 225
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$price_start /Users/saleem/Sites/spos/themes/default/views/settings/index.php 236
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$price_chars /Users/saleem/Sites/spos/themes/default/views/settings/index.php 246
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$price_divide_by /Users/saleem/Sites/spos/themes/default/views/settings/index.php 256
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$weight_start /Users/saleem/Sites/spos/themes/default/views/settings/index.php 268
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$weight_chars /Users/saleem/Sites/spos/themes/default/views/settings/index.php 278
ERROR - 2021-10-11 15:33:14 --> Severity: Warning --> Undefined property: stdClass::$weight_divide_by /Users/saleem/Sites/spos/themes/default/views/settings/index.php 288
ERROR - 2021-10-11 15:33:41 --> 404 Page Not Found: Uploads/logo1.png
ERROR - 2021-10-11 16:02:26 --> 404 Page Not Found: Faviconico/index
